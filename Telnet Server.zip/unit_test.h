#include <iostream>
#include <string>

using namespace std;

bool isParentDirectory(string child, string parent);
bool fileExists(string needle, string haystack);
